# Script: { name }

{ A short description of what your script does. }

![skeleton](screenshots/1.png)


## Dependencies

{ Perhaps a few words about the dependencies and requirements, if necessary }


## Configuration

{ Perhaps a few words about the configuration, if necessary }


## Module

```ini
[module/{ name }]
type = custom/script
exec = ~/polybar-scripts/{ name }.sh
interval =
...
```
