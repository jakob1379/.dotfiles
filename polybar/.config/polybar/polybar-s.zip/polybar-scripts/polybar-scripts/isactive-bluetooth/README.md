# Script: isactive-bluetooth

A script that shows if bluetooth is on or off.


## Module

```ini
[module/isactive-bluetooth]
type = custom/script
exec = ~/polybar-scripts/isactive-bluetooth.sh
interval = 10
```
