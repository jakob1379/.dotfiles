# Script: vpn-openvpn-isrunning

A script that shows if OpenVPN is running.

![vpn-openvpn-isrunning](screenshots/1.png)


## Module

```ini
[module/vpn-openvpn-isrunning]
type = custom/script
exec = ~/polybar-scripts/vpn-openvpn-isrunning.sh
interval = 5
```
